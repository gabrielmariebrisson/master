package Component;

import java.util.List;

public interface Patisserie {
    String getName();
    int getPrice();
}