package ConcreteComponent;

import java.util.ArrayList;
import java.util.List;

import Component.Patisserie;

public class Choux extends Gateau {
    public Choux() {
        super("Choux",10);
    }
}