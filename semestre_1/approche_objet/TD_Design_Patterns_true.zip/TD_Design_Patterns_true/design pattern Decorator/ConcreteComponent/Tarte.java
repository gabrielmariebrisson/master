package ConcreteComponent;

import java.util.ArrayList;
import java.util.List;

import Component.Patisserie;

public class Tarte extends Gateau {
    public Tarte() {
        super("Tarte",10);
    }
}