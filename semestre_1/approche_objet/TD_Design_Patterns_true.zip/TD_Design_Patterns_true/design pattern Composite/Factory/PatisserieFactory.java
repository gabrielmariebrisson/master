package Factory;

import Component.Patisserie;

public interface PatisserieFactory {
    Patisserie createPatisserie();
}

