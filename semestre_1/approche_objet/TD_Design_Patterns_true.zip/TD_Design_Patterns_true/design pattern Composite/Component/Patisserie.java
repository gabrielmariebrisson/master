package Component;

public interface Patisserie {
    public String getName();
    public int getPrice();
}