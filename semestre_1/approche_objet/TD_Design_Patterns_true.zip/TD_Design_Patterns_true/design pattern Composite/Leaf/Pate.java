package Leaf;
import Component.Patisserie;


public class Pate implements Patisserie {
    @Override
    public  String getName() {
        return "";
    }

    @Override
    public  int getPrice() {
        return 1;
    }
}