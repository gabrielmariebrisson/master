package DesignPatternObserver;

public interface Subscriber {
    void update(int seuil);
}
